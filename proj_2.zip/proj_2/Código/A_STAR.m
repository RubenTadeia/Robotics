function node_path = A_STAR(q_init,q_goal,g,map,n,node_info)

node_init = map(q_init(1),q_init(2));
node_goal = map(q_goal(1),q_goal(2));

if node_init == 0 || node_goal == 0
    
    node_path = [];
    return
    
end

grey   = zeros(1,n);
father = zeros(1,n);
step   = 1;

grey(node_init) = 1;
queue           = [ node_init; 0 ];

node       = queue(1,1);
queue(:,1) = [];
while node ~= node_goal
    
    children  = find(g(node,:));
    for i = 1:length(children)
        
        if grey(children(i)) == 0
            
            grey(children(i))   = 1;
            father(children(i)) = node;
            
            queue = ENQUEUE(children(i),(step + H(q_goal,children(i),node_info)),queue);
            
        end
        
    end
    
    step = step + 1;
    
    if isempty(queue)
        
        node_path = [];
        return
        
    else
        
        node       = queue(1,1);
        queue(:,1) = [];
        
    end
    
end

node = node_goal;
node_path = node;
while node ~= node_init
    
    node = father(node);
    node_path = [ node node_path ];
    
end

end