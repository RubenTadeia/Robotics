function [ map n node_info ] = DECOMPOSE(node,map,n,node_info,w,res)

m_i = node(1);
m_f = node(2);
n_i = node(3);
n_f = node(4);

label = LABEL(node,w);

switch label
    
    case 'EMPTY'
        
        n = n + 1;
        map(m_i:m_f,n_i:n_f) = n;
        node_info = [ node_info; node ];
        
    case 'MIXED'
        
        if m_f - m_i > res
            
            node_1 = [ m_i, fix((m_i + m_f - 1)/2), n_i, fix((n_i + n_f - 1)/2) ];
            node_2 = [ m_i, fix((m_i + m_f - 1)/2), fix((n_i + n_f + 1)/2), n_f ];
            node_3 = [ fix((m_i + m_f + 1)/2), m_f, n_i, fix((n_i + n_f - 1)/2) ];
            node_4 = [ fix((m_i + m_f + 1)/2), m_f, fix((n_i + n_f + 1)/2), n_f ];
            
            [ map n node_info ] = DECOMPOSE(node_1,map,n,node_info,w,res);
            [ map n node_info ] = DECOMPOSE(node_2,map,n,node_info,w,res);
            [ map n node_info ] = DECOMPOSE(node_3,map,n,node_info,w,res);
            [ map n node_info ] = DECOMPOSE(node_4,map,n,node_info,w,res);
            
        end
        
end

end