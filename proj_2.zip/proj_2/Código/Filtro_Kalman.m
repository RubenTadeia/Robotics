
% % % % % % % % Filtro de Kalman

%%%%%%%%%%%%%%%%%%  Matrizes inicializadas no �nicio do ciclo

% Defini��o da matriz R, matriz de co-vari�ncia que deve descrever os 
% erros associados �s medi��es

    ruido % valor do desvio padr�o do ru�do se suposto branco gaussiano


    R=[(ruido/2)^2 0 0;
        0 (ruido/2)^2 0;
        0 0 (ruido/2)^2];



    % inicializa��o das matrizes H com modelo de observa��o e P de predi��o da co-vari�ncia � 

    
    H=[1 0 0;
        0 1 0;
        0 0 1];
    
    P=inv(H)*R*inv(H');

    
    tstep  % intervalo de tempo entre dois passos do ciclo

%%%%%%%%%%%%%%%%%%  Procedimentos a fazer em cada ciclo

    last=[xlast;ylast;thetalast]; % �ltima posi��o e postura do �ponto 
% anterior
    
    medido=[x;y;thetareal] % valor medido a partir da odometria do robot
    
    increment=[v*tstep*cos(last(3)*2*pi/360);v*tstep*sin(last(3)*2*pi/360);w*tstep]   % incremento derivado da navega��o do robot com velocidade 
% linear e angular v e w e intervalo de tempo tstep


    
    previsto=last+increment;
    if previsto(3)>180
        previsto(3)=previsto(3)-360;
    elseif previsto(3)<-180
        previsto(3)=previsto(3)+360;
    end
    
% correc��o para que o �ngulo venha no intervalo [-180;180]   
    % Matriz com o modelo de transi��o de estados no intervalo de tempo %tstep

    F=[1 0 -v*tstep*sin(previsto(3)*2*pi/360);
        0 1 v*tstep*cos(previsto(3)*2*pi/360);
        0 0 1];
    
    % actualiza��o da matriz de predi��o de co-vari�ncia

    P=F*P*F';
    
    K=P*H'*inv(H*P*H'+R);  %calcular ganho de kalman    
                  
    %calcular res�duo da medi��o;
    dif=medido-previsto
    
    %Actualiza��o do estado
    
    corrigido=previsto+K*dif

    x=corrigido(1);
    y=corrigido(2);
    thetareal=corrigido(3);
    
    if thetareal>180
        thetareal=thetareal-360
    elseif thetareal<-180
        thetareal=thetareal+360
    else thetareal
    end

   
% Actualiza��o da matriz de predi��o da covari�ncia
 P=P-K*H*P;    




