function [ mapout ] = fechasalas( mapa,p0,pf )

% Esta fun��o faz um pr�-processamento do mapa e veda o acesso ao robot de
% salas que n�o v�o ser utilizadas durante o procedimento, de forma a
% melhorar a efici�ncia do algoritmo e evitar trabalho desnecess�rio.

mapout=mapa;
%fechar salas norte
if (3<p0(1)&&p0(1)<142&&189<p0(2)&&p0(2)<458)...
        ||(3<pf(1)&&pf(1)<142&&189<pf(2)&&pf(2)<458)
else mapout(3:142,189:458)=zeros(142-2,458-188);
end

%fechar salas oeste
if (179<p0(1)&&p0(1)<449&&5<p0(2)&&p0(2)<147)...
        ||(179<pf(1)&&pf(1)<449&&5<pf(2)&&pf(2)<147)
else mapout(179:449,5:147)=zeros(449-178,147-4);
end
%fechar salas sul
if (495<p0(1)&&p0(1)<635&&190<p0(2)&&p0(2)<461)...
        ||(495<pf(1)&&pf(1)<635&&190<pf(2)&&pf(2)<461)
else mapout(495:635,190:461)=zeros(635-494,461-189);
end
%fechar elevador
if (216<p0(1)&&p0(1)<285&&185<p0(2)&&p0(2)<321)...
        ||(216<pf(1)&&pf(1)<285&&185<pf(2)&&pf(2)<321)
else mapout(216:285,185:321)=zeros(285-215,321-184);
end
%fechar salas este
if (183<p0(1)&&p0(1)<453&&501<p0(2)&&p0(2)<637)...
        ||(183<pf(1)&&pf(1)<453&&501<pf(2)&&pf(2)<637)
else mapout(183:453,501:637)=zeros(453-182,637-500);
end

%Fechar sala NW
if (6<p0(1)&&p0(1)<141&&8<p0(2)&&p0(2)<184)||...
        (6<pf(1)&&pf(1)<141&&8<pf(2)&&pf(2)<184)||...
        (142<p0(1)&&p0(1)<180&&8<p0(2)&&p0(2)<144)||...
        (142<pf(1)&&pf(1)<180&&8<pf(2)&&pf(2)<144)
      
else mapout(6:141,8:184)=zeros(141-5,184-7);
    mapout(142:180,8:144)=zeros(180-141,144-7);
end

%Fechar sala NE
if (4<p0(1)&&p0(1)<141&&462<p0(2)&&p0(2)<639)||...
        (4<pf(1)&&pf(1)<141&&462<pf(2)&&pf(2)<639)||...
        (142<p0(1)&&p0(1)<180&&501<p0(2)&&p0(2)<637)||...
        (142<pf(1)&&pf(1)<180&&501<pf(2)&&pf(2)<637)
else mapout(4:141,462:639)=zeros(141-3,639-461);
    mapout(142:180,501:637)=zeros(180-141,637-500);
end
%Fechar sala SW

if (452<p0(1)&&p0(1)<494&&10<p0(2)&&p0(2)<146)||...
        (452<pf(1)&&pf(1)<494&&10<pf(2)&&pf(2)<146)||...
        (495<p0(1)&&p0(1)<634&&10<p0(2)&&p0(2)<187)||...
        (495<pf(1)&&pf(1)<634&&10<pf(2)&&pf(2)<187)
else mapout(452:494,10:146)=zeros(494-451,146-9);
    mapout(495:634,10:187)=zeros(634-494,187-9);
end

%Fechar sala SE

if (455<p0(1)&&p0(1)<496&&501<p0(2)&&p0(2)<638)||...
        (455<pf(1)&&pf(1)<496&&501<pf(2)&&pf(2)<638)||...
        (497<p0(1)&&p0(1)<634&&463<p0(2)&&p0(2)<638)||...
        (497<pf(1)&&pf(1)<634&&463<pf(2)&&pf(2)<638)
else mapout(455:496,501:638)=zeros(496-454,638-500);
    mapout(497:634,463:638)=zeros(634-496,638-462);
end

for i=6:634
    for j=6:634
        if mapa(i,j)==0
            mapout(i-5:i+5,j-5:j+5)=zeros(11,11);
        end
    end
end



end

