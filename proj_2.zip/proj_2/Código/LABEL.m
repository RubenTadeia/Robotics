function label = LABEL(node,w)

m_i = node(1);
m_f = node(2);
n_i = node(3);
n_f = node(4);

if isempty(find(w(m_i:m_f,n_i:n_f),1))
    
    label = 'EMPTY';
    
elseif isempty(find(-w(m_i:m_f,n_i:n_f) + 1,1))
    
    label = 'FULL';
    
else
    
    label = 'MIXED';
    
end