function [ via ] = Real_test( p0,pf,real,v )
%REAL_TEST A fun�ao Real_test � semelhante � interface criada e � o resumo
%de todo o projecto.
% Recebe uma posi��o inicial e final, um valor chamado real que permite
% come�ar a simula��o de seguida ou apenas calcular a traject�ria para usar
% na fun�ao pathfollow e a velocidade caso seja pretendido come�ar a
% simula��o de imediato.
%   Detailed explanation goes here

% Leitura do ficheiro mapa

mapa=imread('mapa.bmp');

% Exibi��o de figura com o mapa, posi��o inicial e final.
figure(1),
imshow(mapa);hold on;
plot(p0(2),p0(1),'o');
plot(pf(2),pf(1),'og'); legend('Posi��o inicial','Posi��o final')
hold off;
pause(0.001);

% Fechar salas desnecess�rias e cria��o de grafo e �rvore.
fechada=fechasalas2(mapa,p0,pf);
[arvore,fp]=freepoints(fechada);

% Exibi��o dos pontos livres
close(1);
figure(2),
imshow(fechada); hold on;
for k=1:length(fp)
    plot(fp(k).freepoint(2),fp(k).freepoint(1),'.');
end
pause(0.001);

% Algoritmo de pesquisa e cria��o de pontos vi�rios

pathpts=pesquisafp( arvore,fp,p0,pf,mapa);
close(2);
pause(0.001);
figure(3),
imshow(mapa); hold on;
plot(pathpts(:,2),pathpts(:,1),'o');

ratio=28500/640;

% Interpola��o e exibi��o no mapa
[y,x,ppx,ppy]=interpolation(pathpts,1,10000)
imshow(mapa); hold on;
plot(y,x);

% Convers�o para unidades reais

for k=1:length(pathpts(:,1));
    path_real(k,:)=ratio*(pathpts(k,:)-p0);
end
close(3)


figure(4);

imshow(mapa); hold on;
[y,x,ppx,ppy]=interpolation(path_real,1,10000)
plot(y,x);
via=transpose([x;y]);

% �nicio de simula��o caso pretendido
if real==1
    
    
    rob=serial_port_start();
    
    pathfollow_real_ang(rob,via,v);

end




end

