function queue = ENQUEUE(node,node_cost,queue)

l = length(queue(1,:));
for i = 1:l
    
    if node_cost < queue(2,i)
        
        queue = [ queue(:,1:(i - 1)), [ node; node_cost ], queue(:,i:l) ];
        break
        
    end
    
end

if length(queue(1,:)) == l
    
    queue(:,end + 1) = [ node; node_cost ];
    
end

end