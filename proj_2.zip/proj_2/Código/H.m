function h = H(q_goal,node,node_info)

m_i = node_info(node,1);
m_f = node_info(node,2);
n_i = node_info(node,3);
n_f = node_info(node,4);

q(1) = round((m_i + m_f - 1)/2);
q(2) = round((n_i + n_f - 1)/2);

h = norm(q_goal - q);

end