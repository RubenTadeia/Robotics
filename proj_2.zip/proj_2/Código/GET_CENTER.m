function q = GET_CENTER(node,node_info)

m_i = node_info(node,1);
m_f = node_info(node,2);
n_i = node_info(node,3);
n_f = node_info(node,4);

q(1) = (m_i + m_f - 1)/2;
q(2) = (n_i + n_f - 1)/2;

end